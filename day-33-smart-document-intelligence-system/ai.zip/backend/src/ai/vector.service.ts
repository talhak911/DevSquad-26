import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Pinecone } from '@pinecone-database/pinecone';
import { v2 as cloudinary } from 'cloudinary';
import * as pdf from 'pdf-parse';
import * as fs from 'fs';

@Injectable()
export class VectorService implements OnModuleInit {
  private readonly logger = new Logger(VectorService.name);
  private pinecone: Pinecone;
  private readonly indexName = 'document-intelligence';

  constructor(private configService: ConfigService) {
    const apiKey = this.configService.get<string>('PINECONE_API_KEY');
    if (!apiKey) {
      this.logger.error('PINECONE_API_KEY is missing from environment variables');
      throw new Error('PINECONE_API_KEY is missing');
    }
    
    this.pinecone = new Pinecone({
      apiKey: apiKey,
    });

    cloudinary.config({
      cloud_name: this.configService.get<string>('CLOUDINARY_CLOUD_NAME'),
      api_key: this.configService.get<string>('CLOUDINARY_API_KEY'),
      api_secret: this.configService.get<string>('CLOUDINARY_API_SECRET'),
    });
  }

  async onModuleInit() {
    await this.ensureIndex();
  }

  private async ensureIndex() {
    this.logger.log('Checking Pinecone index status...');
    try {
      const indexes = await this.pinecone.listIndexes();
      const exists = indexes.indexes?.some(idx => idx.name === this.indexName);
      
      if (!exists) {
        this.logger.log(`Creating Pinecone index: ${this.indexName}...`);
        await this.pinecone.createIndex({
          name: this.indexName,
          dimension: 768, // text-embedding-004 dimensions
          metric: 'cosine',
          spec: {
            serverless: {
              cloud: 'aws',
              region: 'us-east-1'
            }
          }
        });
        this.logger.log(`Index ${this.indexName} creation initiated.`);
      } else {
        this.logger.log(`Index ${this.indexName} already exists.`);
      }
    } catch (error) {
      this.logger.error(`Error ensuring Pinecone index: ${error.message}`, error.stack);
    }
  }

  async uploadToCloudinary(filePath: string): Promise<string> {
    this.logger.log(`Uploading ${filePath} to Cloudinary...`);
    const result = await cloudinary.uploader.upload(filePath, {
      resource_type: 'raw',
      folder: 'ai-documents',
    });
    return result.secure_url;
  }

  async deleteDocument(documentId: string, cloudinaryUrl?: string): Promise<void> {
    this.logger.log(`Deleting document ${documentId} from Cloudinary and Pinecone...`);
    
    try {
      // 1. Delete from Cloudinary if URL is provided
      if (cloudinaryUrl) {
        const parts = cloudinaryUrl.split('/');
        const fileName = parts[parts.length - 1];
        // More robust public ID extraction
        const publicId = `ai-documents/${fileName.substring(0, fileName.lastIndexOf('.'))}`;
        
        this.logger.log(`Deleting from Cloudinary: ${publicId}`);
        await cloudinary.uploader.destroy(publicId, { resource_type: 'raw' }).catch(err => {
          this.logger.warn(`Cloudinary deletion failed for ${publicId}: ${err.message}`);
        });
      }

      // 2. Delete from Pinecone
      const index = this.pinecone.index(this.indexName);
      
      this.logger.log(`Attempting to delete vectors for document ${documentId}...`);
      
      // Attempt 1: Delete by filter (standard way)
      // Some serverless configurations might have issues with deleteMany + filter
      // returning 404 if no vectors match or if the endpoint is finicky.
      try {
        await index.deleteMany({
          filter: { documentId: { '$eq': documentId } }
        });
        this.logger.log(`Successfully deleted vectors by filter for ${documentId}.`);
      } catch (filterError) {
        this.logger.warn(`deleteMany by filter failed: ${filterError.message}. Attempting ID-based deletion...`);
        
        // Fallback: Query for IDs first and then delete them
        const queryResponse = await index.query({
          vector: Array(768).fill(0), // text-embedding-004 is 768
          filter: { documentId: { '$eq': documentId } },
          topK: 1000,
          includeMetadata: false
        });

        const ids = queryResponse.matches?.map(m => m.id) || [];
        if (ids.length > 0) {
          this.logger.log(`Found ${ids.length} vectors, deleting by ID...`);
          await index.deleteMany(ids);
          this.logger.log(`Successfully deleted ${ids.length} vectors by ID.`);
        } else {
          this.logger.log(`No vectors found for document ${documentId}.`);
        }
      }
      
      this.logger.log(`Successfully completed resource cleanup for ${documentId}.`);
    } catch (error) {
      this.logger.error(`Error during document resource cleanup: ${error.message}`, error.stack);
      // We don't necessarily want to block the DB deletion if Pinecone is being difficult, 
      // but the user wants to know if it failed.
      throw error;
    }
  }

  async getEmbedding(text: string): Promise<number[]> {
    const apiKey = this.configService.get<string>('GEMINI_API_KEY');
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/text-embedding-004:embedContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          content: { parts: [{ text }] }
        }),
      }
    );
    if (!res.ok) throw new Error(`Gemini Embedding Error: ${await res.text()}`);
    const data = await res.json();
    return data.embedding.values;
  }

  async processDocument(documentId: string, filePath: string): Promise<void> {
    this.logger.log(`Processing document ${documentId} for vector store...`);
    
    try {
      // 1. Extract text
      const dataBuffer = fs.readFileSync(filePath);
      const data = await (pdf as any)(dataBuffer);
      const text = data.text;

      // 2. Chunk text
      const chunks = this.chunkText(text, 1000);
      this.logger.log(`Created ${chunks.length} chunks.`);

      const index = this.pinecone.index(this.indexName);
      
      const vectors = await Promise.all(chunks.map(async (chunk, i) => {
        const values = await this.getEmbedding(chunk);
        
        return {
          id: `${documentId}_${i}`,
          values,
          metadata: {
            documentId,
            text: chunk,
            page: i + 1,
          },
        };
      }));

      await index.upsert(vectors as any);
      this.logger.log(`Successfully upserted ${vectors.length} vectors to Pinecone.`);
    } catch (error) {
      this.logger.error(`Failed to process document for vector store: ${error.message}`);
      throw error;
    }
  }

  private chunkText(text: string, size: number): string[] {
    const chunks: string[] = [];
    let current = 0;
    while (current < text.length) {
      chunks.push(text.substring(current, current + size));
      current += size - 100; // 100 char overlap
    }
    return chunks;
  }

  async search(documentId: string, query: string): Promise<string[]> {
    const index = this.pinecone.index(this.indexName);
    const vector = await this.getEmbedding(query);
    
    const results = await index.query({
      vector,
      filter: { documentId: { '$eq': documentId } },
      topK: 3,
      includeMetadata: true,
    });

    return results.matches?.map(m => (m.metadata as any)?.text).filter(Boolean) || [];
  }
}
