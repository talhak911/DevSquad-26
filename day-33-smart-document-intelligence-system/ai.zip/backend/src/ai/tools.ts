import { tool } from '@openai/agents';
import { z } from 'zod';
import * as fs from 'fs';
// @ts-ignore
import pdf = require('pdf-parse');
import { VectorService } from './vector.service';

// PDF Text Extraction Tool
export const pdfExtractionTool = tool({
  name: 'pdfExtraction',
  description: 'Extract raw text content from a PDF file.',
  parameters: z.object({
    filePath: z.string().describe('The absolute path to the PDF file.'),
  }),
  execute: async ({ filePath }: { filePath: string }) => {
    console.log(`\n[Tool: pdfExtraction] Extracting from: ${filePath}`);
    try {
      const dataBuffer = fs.readFileSync(filePath);
      const data = await (pdf as any)(dataBuffer);
      console.log(`[Tool: pdfExtraction] Extracted ${data.text.length} characters.`);
      return data.text;
    } catch (e) {
      console.error(`[Tool: pdfExtraction] Error: ${e.message}`);
      return `Error extracting PDF: ${e.message}`;
    }
  },
});

// Semantic Retriever Tool (Professional RAG)
export const getSemanticRetrieverTool = (vectorService: VectorService) => tool({
  name: 'semanticRetriever',
  description: 'Retrieve semantically relevant chunks from the document based on a natural language query using Pinecone.',
  parameters: z.object({
    documentId: z.string().describe('The database ID of the document.'),
    query: z.string().describe('The natural language question or query.'),
  }),
  execute: async ({ documentId, query }: { documentId: string, query: string }) => {
    console.log(`\n[Tool: semanticRetriever] Searching Pinecone for "${query}" in doc ${documentId}`);
    try {
      const results = await vectorService.search(documentId, query);
      if (results.length === 0) return "No relevant sections found using semantic search.";
      return results.join('\n---\n');
    } catch (e) {
      return `Error in semantic search: ${e.message}`;
    }
  },
});

// Section Locator Tool
export const sectionLocatorTool = tool({
  name: 'sectionLocator',
  description: 'Locate and extract specific sections like "Introduction", "Methodology", "Conclusion", or "TOC".',
  parameters: z.object({
    filePath: z.string().describe('The path to the PDF file.'),
    sectionName: z.string().describe('The name of the section to locate.'),
  }),
  execute: async ({ filePath, sectionName }: { filePath: string, sectionName: string }) => {
    console.log(`\n[Tool: sectionLocator] Locating section: ${sectionName}`);
    try {
      const dataBuffer = fs.readFileSync(filePath);
      const data = await (pdf as any)(dataBuffer);
      const text = data.text;
      
      const regex = new RegExp(`(?:^|\\n)([\\d\\.]*\\s*${sectionName}[^\\n]*)([\\s\\S]*?)(?=\\n(?:[\\d\\.]*\\s*[A-Z][^\\n]{5,})|$)`, 'i');
      const match = text.match(regex);
      
      if (!match) {
        return `Section "${sectionName}" not found. Try identifying sections first with the analysis agent.`;
      }

      return `Section: ${match[1]}\nContent: ${match[2].trim().substring(0, 2000)}`;
    } catch (e) {
      return `Error locating section: ${e.message}`;
    }
  },
});
