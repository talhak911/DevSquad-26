import { Injectable, Logger } from '@nestjs/common';
import { Agent, run, Runner } from '@openai/agents';
import { setTracingDisabled } from '@openai/agents-core';
import { createAgents } from './agents';
import { GeminiProvider } from './geminiProvider';
import { VectorService } from './vector.service';

// Disable SDK tracing to avoid conflicts with Gemini
setTracingDisabled(true);

@Injectable()
export class AIService {
  private readonly logger = new Logger(AIService.name);
  private readonly provider = new GeminiProvider();

  constructor(private readonly vectorService: VectorService) {}

  private validateInput(message: string): boolean {
    const blockedPatterns = [
      /password/i, /hack/i, /exploit/i, /malware/i, 
      /ignore previous instructions/i, /system prompt/i
    ];
    return !blockedPatterns.some(pattern => pattern.test(message));
  }

  async chat(message: string, filePath?: string, documentId?: string): Promise<any> {
    if (!this.validateInput(message)) {
      return {
        finalOutput: "Guardrail: Your query contains potentially unsafe patterns and has been blocked.",
        messages: [],
        agent: { name: 'Guardrail System' }
      };
    }

    // Enrich message with context
    let input = message;
    if (filePath) input = `[Document Path: ${filePath}]\n${input}`;
    if (documentId) input = `[Document ID: ${documentId}]\n${input}`;

    this.logger.log(`Starting agentic run with input: ${input.substring(0, 100)}...`);
    
    try {
      const { routerAgent } = createAgents(this.vectorService);

      const runner = new Runner({
        modelProvider: this.provider,
      });

      const result = await runner.run(routerAgent as any, input, {
        maxTurns: 10,
      });

      this.logger.log(`Agentic run completed successfully.`);
      return {
        finalOutput: result.finalOutput,
        messages: (result as any).messages || [],
        agent: (result as any).agent || null,
      };
    } catch (error) {
      this.logger.error(`Agentic run failed: ${error.message}`);
      throw error;
    }
  }
}
