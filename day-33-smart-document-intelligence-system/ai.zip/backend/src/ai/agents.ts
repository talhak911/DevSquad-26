import { Agent } from '@openai/agents';
import { pdfExtractionTool, getSemanticRetrieverTool, sectionLocatorTool } from './tools';
import { VectorService } from './vector.service';

const MODEL = 'gemini-1.5-flash';

export const createAgents = (vectorService: VectorService) => {
  const semanticRetriever = getSemanticRetrieverTool(vectorService);

  // 1. Document Analysis Agent
  const analysisAgent = new Agent({
    name: 'Document Analysis Agent',
    model: MODEL,
    instructions: `You are an expert document analyst. 
    Your responsibility is to analyze the content of the uploaded PDF and identify:
    - Document type (Research Paper, Business Report, Legal/Policy, Manual/Guide, etc.)
    - Key sections (Introduction, Results, Conclusion, etc.)
    - Important entities (Names, Organizations, Dates, etc.)
    MANDATORY: Always use the pdfExtraction tool to get the content first.
    OUTPUT FORMAT: Provide your analysis in a clear, structured way. Identify the document type and main sections explicitly.`,
    tools: [pdfExtractionTool, sectionLocatorTool],
  });

  // 2. Summary Agent
  const summaryAgent = new Agent({
    name: 'Summary Agent',
    model: MODEL,
    instructions: `You are a professional summarizer.
    Your responsibility is to generate:
    - Document type identification (Research Paper, Report, etc.)
    - An executive summary (max 3 paragraphs)
    - Bulleted key highlights (max 5 points)
    - A comma-separated list of key entities (organizations, people, locations)
    Adapt your summary style to the document type.
    MANDATORY: Always use the pdfExtraction tool to get the context.
    OUTPUT FORMAT: Start with "TYPE: [Document Type]", then "EXECUTIVE SUMMARY:" followed by the summary, then "HIGHLIGHTS:" followed by the bullet points, then "ENTITIES:" followed by the list.`,
    tools: [pdfExtractionTool],
  });

  // 3. Q&A Agent
  const qaAgent = new Agent({
    name: 'Q&A Agent',
    model: MODEL,
    instructions: `You are a specialized Q&A assistant.
    Your responsibility is to answer user questions strictly from the document context provided.
    RULES:
    - Use the sectionLocator tool if the user asks for a specific section.
    - Use the semanticRetriever tool for general questions about document content.
    - If the information is not present in the document, respond: "This information is not present in the document."
    - NO hallucination. NO external knowledge.
    - Be precise and cite sections if possible.`,
    tools: [semanticRetriever, sectionLocatorTool],
  });

  // 4. Router Agent
  const routerAgent = new Agent({
    name: 'Router Agent',
    model: MODEL,
    instructions: `You are the primary triage assistant for the Document Intelligence System.
    Your responsibilities:
    1. GUARDRAIL: Analyze user intent. If the query is inappropriate, unsafe, or unrelated to the document, refuse to answer and DO NOT hand off.
    2. ROUTING: 
       - If the user wants to understand what the document is about or analyze its structure, hand off to the Document Analysis Agent.
       - If the user wants a summary or highlights, hand off to the Summary Agent.
       - If the user has a specific question about the document content, hand off to the Q&A Agent.
    3. MANDATORY: The Router agent never answers questions directly. Always hand off to a specialized agent.`,
    handoffs: [analysisAgent, summaryAgent, qaAgent],
  });

  return { routerAgent, analysisAgent, summaryAgent, qaAgent };
};
